<?php
require_once("config.php");

if (!isset($_GET['c']) || $_GET['c'] == '') {
    header('location: index.php');
    return;
}
$codigo = $_GET['c'];
$patrimonio = new Patrimonio();
$patrimonioEditar = $patrimonio->Procura($codigo);



$categoria = new Categoria();
$lista_categorias = $categoria->Listar();

$localizacao = new Localizacao();
$listaLocalizacoes = $localizacao->Listar();

$responsavel = new Responsavel();
$listaResponsaveis = $responsavel->Listar();

$situacao = new Situacao();
$listaSituacoes = $situacao->Listar();

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet"
        href="https:fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
    <link rel="stylesheet" href="css/estiloPatrimonio.css">
    <link rel="stylesheet" href="css/estiloFormulario.css">
</head>

<body>

    <header>
        <h1>Editar Patrimônio</h1>
        <div class="area-links">
            <a href="index.php"><span class="material-symbols-outlined">arrow_back</span> Voltar</a>
        </div>
    </header>

    <main class="principal">
        <form action="salvarEdicao.php?" method="get">
            <h1><?= $patrimonioEditar[0]->Nome ?></h1>
            <input type="hidden" name="c" value="<?= $patrimonioEditar[0]->Codigo ?>">
            <div class="linha">
                <div class="item">
                    <div class="texto">Nome do Patromônio:</div>
                    <div class="valor"><input type="text" name="txtNome" value="<?= $patrimonioEditar[0]->Nome ?>"></div>
                </div>

                <div class="item">
                    <div class="texto">Número de Série:</div>
                    <div class="valor"><input type="text" name="txtNumeroSerie" value="<?= $patrimonioEditar[0]->NumeroSerie ?>">
                    </div>
                </div>
            </div>

            <div class="linha">
                <div class="item">
                    <div class="texto">Categoria:</div>
                    <div class="valor">
                        <select name="cmbCategoria">
                            <?php
                            for ($i = 0; $i < count($lista_categorias); $i++) {
                                if ($lista_categorias[$i]->Nome == $patrimonioEditar[0]->Categoria) {
                                  echo  "<option selected value='{$lista_categorias[$i]->Codigo}'>{$lista_categorias[$i]->Nome}</option>";
                                } else {
                                  echo  "<option value='{$lista_categorias[$i]->Codigo}'>{$lista_categorias[$i]->Nome}</option>";
                                }
                            }
                            ?>


                        </select>
                    </div>
                </div>
                <div class="item">
                    <div class="texto">Localização:</div>
                    <div class="valor">
                        <select name="cmbLocalizacao">
                            <?php
                            for ($i = 0; $i < count($listaLocalizacoes); $i++) {
                                if ($listaLocalizacoes[$i]->Nome == $patrimonioEditar[0]->Localizacao) {
                                  echo  "<option selected value='{$listaLocalizacoes[$i]->Codigo}'>{$listaLocalizacoes[$i]->Nome}</option>";
                                } else {
                                   echo "<option value='{$listaLocalizacoes[$i]->Codigo}'>{$listaLocalizacoes[$i]->Nome}</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="linha">
                <div class="item">
                    <div class="texto">Responsável:</div>
                    <div class="valor">
                        <select name="cmbResponsavel">
                            <?php
                            for ($i = 0; $i < count($listaResponsaveis); $i++) {
                                if ($listaResponsaveis[$i]->Nome == $patrimonioEditar[0]->Responsavel) {
                                  echo  "<option selected value='{$listaResponsaveis[$i]->Codigo}'>{$listaResponsaveis[$i]->Nome}</option>";
                                } else {
                                   echo "<option value='{$listaResponsaveis[$i]->Codigo}'>{$listaResponsaveis[$i]->Nome}</option>";
                                }
                            }
                            ?>

                        </select>
                    </div>
                </div>
                <div class="item">
                    <div class="texto">Data de Aquisição:</div>
                    <div class="valor"><input type="date" name="txtDataAquisicao"
                            value="<?= $patrimonioEditar[0]->DataAquisicao ?>"></div>
                </div>
            </div>
            <div class="linha">
                <div class="item">
                    <div class="texto">Valor:</div>
                    <div class="valor"><input type="number" name="txtValor" value="<?= $patrimonioEditar[0]->Valor ?>"></div>
                </div>
                <div class="item">
                    <div class="texto">Status:</div>
                    <div class="valor">
                        <select name="cmbSituacao">
                            <?php
                            for ($i = 0; $i < count($listaSituacoes); $i++) {
                                if ($listaSituacoes[$i]->Nome == $patrimonioEditar[0]->Situacao) {
                                  echo  "<option selected value='{$listaSituacoes[$i]->Codigo}'>{$listaSituacoes[$i]->Nome}</option>";
                                } else {
                                  echo  "<option value='{$listaSituacoes[$i]->Codigo}'>{$listaSituacoes[$i]->Nome}</option>";
                                }
                            }
                            ?>


                        </select>
                    </div>
                </div>
            </div>

            <div class="linha">
                <div class="item">
                    <div class="texto">Observações:</div>
                    <div class="valor">
                        <textarea rows="4" name="txtObservacao"><?= $patrimonioEditar[0]->Observacao ?></textarea>
                    </div>
                </div>
            </div>

            <div class="area-botoes">
                <button class="btn btn-editar"><span class="material-symbols-outlined">save</span>Salvar</button>
                <a href="index.php" class="btn btn-voltar"><span
                        class="material-symbols-outlined">arrow_back</span>Voltar</a>
            </div>
        </form>
    </main>

</body>

</html>