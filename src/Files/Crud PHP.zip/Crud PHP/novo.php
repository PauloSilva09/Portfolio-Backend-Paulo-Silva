<?php
require_once("config.php");

$categoria = new Categoria();
$lista_categorias = $categoria->Listar();

$localizacao = new Localizacao();
$listaLocalizacoes =  $localizacao->Listar();

$responsavel = new Responsavel();
$listaResponsaveis = $responsavel->Listar();

$situacao = new Situacao();
$listaSituacoes = $situacao->Listar();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
    <link rel="stylesheet" href="css/estiloPatrimonio.css">
    <link rel="stylesheet" href="css/estiloFormulario.css">
</head>

<body>

    <header>
        <h1>Novo Patrimônio</h1>
        <div class="area-links">
            <a href="index.php"><span class="material-symbols-outlined">arrow_back</span> Voltar</a>
        </div>
    </header>

    <main class="principal">
        <form action="salvarNovo.php" method="get">
            <div class="linha">
                <div class="item">
                    <div class="texto">Nome do Patrimônio:</div>
                    <div class="valor"><input type="text" name="txtNome"></div>
                </div>

                <div class="item">
                    <div class="texto">Número de Série:</div>
                    <div class="valor"><input type="text" name="txtNumeroSerie"></div>
                </div>
            </div>
            
            <div class="linha">
                <div class="item">
                    <div class="texto">Categoria:</div>
                    <div class="valor">
                        <select name="cmbCategoria">
                            <option value="-1" selected disabled>-- Selecione --</option>
                            <?php
                            for ($i=0; $i < count($lista_categorias); $i++) { 
                                echo "<option value='{$lista_categorias[$i]->Codigo}'>{$lista_categorias[$i]->Nome}</option>";
                            }
                            ?>
                             
                            <!-- <option>Informática</option>
                            <option>Móveis</option>
                            <option>Veículos</option> -->
                        </select>
                    </div>
                </div>
                <div class="item">
                    <div class="texto">Localização:</div>
                    <div class="valor">
                        <select name="cmbLocalizacao">
                            <option value="-1" selected disabled>-- Selecione --</option>
                            <?php
                            for ($i=0; $i < count($listaLocalizacoes); $i++) { 
                                echo "<option value='{$listaLocalizacoes[$i]->Codigo}'>{$listaLocalizacoes[$i]->Nome}</option>";
                            }
                            ?>
                            <!-- <option>Escritório Central - Sala 03</option>
                            <option>Almoxarifado</option>
                            <option>Filial Norte</option> -->
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="linha">
                <div class="item">
                    <div class="texto">Responsável:</div>
                    <div class="valor">
                        <select name="cmbResponsavel">
                            <option value="-1" selected disabled>-- Selecione --</option>
                            <?php
                            for ($i=0; $i < count($listaResponsaveis); $i++) { 
                                echo "<option value='{$listaResponsaveis[$i]->Codigo}'>{$listaResponsaveis[$i]->Nome}</option>";
                            }
                            ?>
                            <!-- <option>Ana Pereira</option>
                            <option>José Silva</option>
                            <option>Carla Souza</option> -->
                        </select>
                    </div>
                </div>
                <div class="item">
                    <div class="texto">Data de Aquisição:</div>
                    <div class="valor"><input type="date" name="txtDataAquisicao"></div>
                </div>
            </div>
            <div class="linha">
                <div class="item">
                    <div class="texto">Valor:</div>
                    <div class="valor"><input type="number" name="txtValor"></div>
                </div>
                <div class="item">
                    <div class="texto">Status:</div>
                    <div class="valor">
                        <select name="cmbSituacao">
                            <option value="-1" selected disabled>-- Selecione --</option>
                            <?php
                            for ($i=0; $i < count($listaSituacoes); $i++) { 
                                echo "<option value='{$listaSituacoes[$i]->Codigo}'>{$listaSituacoes[$i]->Nome}</option>";
                            }
                            ?>
                            <!-- <option>Ativo</option>
                            <option>Em manutenção</option>
                            <option>Baixado</option> -->
                        </select>
                    </div>
                </div>
            </div>

            <div class="linha">
                <div class="item">
                    <div class="texto">Observações:</div>
                    <div class="valor">
                        <textarea rows="4" name="txtObservacao"></textarea>
                    </div>
                </div>
            </div>

            <div class="area-botoes">
                <button  class="btn btn-editar"><span class="material-symbols-outlined">save</span>Salvar</button>
                <a class="btn btn-voltar" href="index.php"><span class="material-symbols-outlined">arrow_back</span>Voltar</a>
            </div>
        </form>
    </main>
</body>

</html>