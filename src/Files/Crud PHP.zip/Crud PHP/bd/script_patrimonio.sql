DROP SCHEMA IF EXISTS inventario_patrimonio;
CREATE SCHEMA inventario_patrimonio;
USE inventario_patrimonio;

CREATE TABLE categoria 
(
    cd_categoria INT ,
    nm_categoria VARCHAR(100),
    CONSTRAINT pk_categoria PRIMARY KEY (cd_categoria)
);

CREATE TABLE localizacao
(
    cd_localizacao INT,
    nm_localizacao VARCHAR(100),
    CONSTRAINT pk_localizacao PRIMARY KEY (cd_localizacao)
);

CREATE TABLE responsavel 
(
    cd_responsavel INT,
    nm_responsavel VARCHAR(100),
    nm_email VARCHAR(100),
    nm_telefone VARCHAR(20),
    CONSTRAINT pk_responsavel PRIMARY KEY (cd_responsavel)
);

CREATE TABLE situacao
(
	cd_situacao INT,
	nm_situacao VARCHAR(100),
	CONSTRAINT pk_situacao PRIMARY KEY (cd_situacao)
);

CREATE TABLE patrimonio
(
    cd_patrimonio INT,
    nm_patrimonio VARCHAR(100),
    cd_numero_serie VARCHAR(50),
    cd_categoria INT,
    cd_localizacao INT,
    cd_responsavel INT,
    dt_aquisicao DATE,
    vl_patrimonio DECIMAL(10,2),
    cd_situacao INT,
    ds_observacao TEXT,
	CONSTRAINT pk_patrimonio PRIMARY KEY (cd_patrimonio),
    CONSTRAINT fk_patrimonio_categoria FOREIGN KEY (cd_categoria) REFERENCES categoria(cd_categoria),
    CONSTRAINT fk_patrimonio_localizacao FOREIGN KEY (cd_localizacao) REFERENCES localizacao(cd_localizacao),
    CONSTRAINT fk_patrimonio_responsavel FOREIGN KEY (cd_responsavel) REFERENCES responsavel(cd_responsavel),
    CONSTRAINT fk_patrimonio_situacao FOREIGN KEY (cd_situacao) REFERENCES situacao(cd_situacao)
);

INSERT INTO categoria VALUES (1, 'Computadores');
INSERT INTO categoria VALUES (2, 'Móveis de Escritório');
INSERT INTO categoria VALUES (3, 'Equipamentos de Informática');
INSERT INTO categoria VALUES (4, 'Ferramentas');

INSERT INTO localizacao VALUES (1, 'Escritório - Andar 1');
INSERT INTO localizacao VALUES (2, 'Armazém');
INSERT INTO localizacao VALUES (3, 'Recepção');
INSERT INTO localizacao VALUES (4, 'Sala de Reuniões');

INSERT INTO responsavel VALUES (1, 'João Silva', 'joao.silva@empresa.com', '(11) 99999-1111');
INSERT INTO responsavel VALUES (2, 'Maria Oliveira', 'maria.oliveira@empresa.com', '(11) 99999-2222');
INSERT INTO responsavel VALUES (3, 'Carlos Souza', 'carlos.souza@empresa.com', '(11) 99999-3333');
INSERT INTO responsavel VALUES (4, 'Ana Pereira', 'ana.pereira@empresa.com', '(11) 99999-4444');

INSERT INTO situacao VALUES (1, 'Ativo');
INSERT INTO situacao VALUES (2, 'Em Manutenção');
INSERT INTO situacao VALUES (3, 'Desativado');

INSERT INTO patrimonio VALUES (1, 'Computador HP', 'SN123456', 1, 1, 1, '2023-01-10', 3500.00, 1, 'Computador de mesa usado para desenvolvimento.');
INSERT INTO patrimonio VALUES (2, 'Mesa de Escritório', 'SN789012', 2, 2, 2, '2022-06-15', 750.00, 1, 'Mesa nova para o setor de vendas.');
INSERT INTO patrimonio VALUES (3, 'Impressora HP', 'SN345678', 3, 3, 3, '2023-03-20', 1200.00, 2, 'Impressora em manutenção.');