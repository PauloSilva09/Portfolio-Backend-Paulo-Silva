<?php
require_once('config.php');

if(!isset($_GET['c']) || $_GET['c'] == '' ){
    header('location: index.php');
    return;
}
$codigo = $_GET['c'];
$patrimonio = new Patrimonio();
$listaPatrimonio = $patrimonio->Procura($codigo);

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
    <link rel="stylesheet" href="css/estiloPatrimonio.css">
</head>

<body>

    <header>
        <h1>Visualizar Patrimônio</h1>
        <div class="area-links">
            <a href="index.php"><span class="material-symbols-outlined">arrow_back</span> Voltar</a>
        </div>
    </header>
    <?php
        for ($i=0; $i < count($listaPatrimonio) ; $i++) { 
            echo "
                <main class='principal'>
                    <h1>{$listaPatrimonio[$i]->Nome}</h1>
                    <div class='linha'>
                        <div class='item'>
                            <div class='texto'>Número de Série/ Status:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->NumeroSerie} - {$listaPatrimonio[$i]->Situacao}</div>
                        </div>
                        <div class='item'>
                            <div class='texto'>Categoria:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->Categoria}</div>
                        </div>
                    </div>

                    <div class='linha'>
                        <div class='item'>
                            <div class='texto'>Localização:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->Localizacao}</div>
                        </div>
                        <div class='item'>
                            <div class='texto'>Responsável:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->Responsavel}</div>
                        </div>
                    </div>

                    <div class='linha'>
                        <div class='item'>
                            <div class='texto'>Data de Aquisição:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->DataAquisicao}</div>
                        </div>
                        <div class='item'>
                            <div class='texto'>Valor:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->Valor}</div>
                        </div>
                    </div>
                    <div class='linha'>
                        <div class='item'>
                            <div class='texto'>Observações:</div>
                            <div class='valor'>{$listaPatrimonio[$i]->Observacao}</div>
                        </div>
                    </div>

                    <div class='area-botoes'>
                        <a href='editar.php?c={$codigo}' class='btn btn-editar'><span class='material-symbols-outlined'>edit</span>Editar</a>
                        <a href='index.php' class='btn btn-voltar'><span class='material-symbols-outlined'>arrow_back</span>Voltar</a>
                    </div>
                </main>";
        }
    
    ?>
</body>

</html>