<?php
require_once("config.php");

if(!isset($_GET['txtNome']) && $_GET['txtNome'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['txtNumeroSerie']) && $_GET['txtNumeroSerie'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['cmbCategoria']) && $_GET['cmbCategoria'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['cmbLocalizacao']) && $_GET['cmbLocalizacao'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['cmbResponsavel']) && $_GET['cmbResponsavel'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['txtDataAquisicao']) && $_GET['txtDataAquisicao'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['txtValor']) && $_GET['txtValor'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['cmbSituacao']) && $_GET['cmbSituacao'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

if(!isset($_GET['txtObservacao']) && $_GET['txtObservacao'] == ""){
    $mensagem = urlencode("Não foi possivel salvar o patrimonio. Tente novamente");
    header('location: index.php?m='. $mensagem);
    return;
}

$nome = $_GET['txtNome']; 
$numeroSerie = $_GET['txtNumeroSerie']; 
$categoria = $_GET['cmbCategoria']; 
$localizacao = $_GET['cmbLocalizacao']; 
$responsavel = $_GET['cmbResponsavel']; 
$dataAquisicao = $_GET['txtDataAquisicao']; 
$valor = $_GET['txtValor']; 
$situacao = $_GET['cmbSituacao']; 
$observacao = $_GET['txtObservacao'];

$patrimonio = new Patrimonio();
$patrimonio->Salvar($nome,$numeroSerie,$categoria,$localizacao,$responsavel,$dataAquisicao,$valor,$situacao,$observacao);

header('location: index.php?');

?>