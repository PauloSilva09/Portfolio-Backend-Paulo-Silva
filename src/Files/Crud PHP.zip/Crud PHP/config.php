<?php

spl_autoload_register(function ($nomeClasse) {
    $nomeCompletoArquivo =  __DIR__ . '/classes/' . $nomeClasse . '.php';
	if (file_exists($nomeCompletoArquivo)) {
		require_once $nomeCompletoArquivo;
	}
});
session_start();

date_default_timezone_set('America/Sao_Paulo');
?>