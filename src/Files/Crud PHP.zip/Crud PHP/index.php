<?php
$existeMensagem = false;
if(isset($_GET['m']) && $_GET['m'] != "")
{
    $m = $_GET['m'];
    $existeMensagem = true;
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
</head>

<body>

    <header>
        <h1>Inventário de Patrimônio</h1>
        <div class="area-links">
            <a href="novo.php"><span class="material-symbols-outlined">add_box</span> Novo Patrimônio</a>
        </div>
    </header>

    <main>
        <form method="GET" action="resultados.php" class="area-barra">
            <input type="text" name="busca" placeholder="Pesquisar por nome, número de série ou categoria...">
            <button type="submit" class="btn"><span class="material-symbols-outlined">search</span>Buscar</button>
        </form>

        <!-- <div id="semPesquisa">
            <span class="material-symbols-outlined">info</span>
            <p>Realize uma pesquisa para ver o patrimônio</p>
        </div>-->

        <?php
        if($existeMensagem == true && $m != ""){
         echo"
            <div id='mensagem'>
            <h1 class='atencao' style='color: red;'>Houve um problema!</h1>
                <p>{$m}</p>
            </div>";
        }
        else{
            echo"
            <div id='semPesquisa'>
                <span class='material-symbols-outlined'>info</span>
                <p>Realize uma pesquisa para ver o patrimônio</p>
            </div>
            ";
        }
        ?>
        
    </main>

</body>

</html>