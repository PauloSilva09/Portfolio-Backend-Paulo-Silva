﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
public class Situacao
{
    public int Codigo { get; set; }
    public string Nome { get; set; }


    public Situacao()
    {
    }

    public Situacao(int codigo,string nome)
    {
        this.Codigo = codigo;
        this.Nome = nome;
    }

    public List<Situacao> Listar()
    {
        List<Situacao> lista = new List<Situacao>();

        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("Select cd_situacao, nm_situacao from situacao order by nm_situacao", conexao);
            MySqlDataReader dados = cSQL.ExecuteReader();


            while (dados.Read())
            {
                Situacao situacao = new Situacao(dados.GetInt32(0), dados.GetString(1));
                lista.Add(situacao);
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }
        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível listar as Situacões");
        }
        finally
        {
            if(conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
        return lista;
    }
}