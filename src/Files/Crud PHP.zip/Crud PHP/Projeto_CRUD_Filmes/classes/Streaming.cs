﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
public class Streaming
{
    public int Codigo { get; set; }
    public string Nome { get; set; }

    public Streaming()
    {

    }
    public Streaming(int codigo, string nome)
    {
        this.Codigo = codigo;
        this.Nome = nome;
    }

    public List<Streaming> Listar()
    {
        List<Streaming> lista = new List<Streaming>();

        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("Select cd_streaming, nm_streaming from streaming order by nm_streaming", conexao);
            MySqlDataReader dados = cSQL.ExecuteReader();
            while (dados.Read())
            {
                Streaming streaming = new Streaming(dados.GetInt32(0), dados.GetString(1));
                lista.Add(streaming);
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }
        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível listar os streaming");
        }
        finally
        {
            if(conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
            return lista;
    }
}