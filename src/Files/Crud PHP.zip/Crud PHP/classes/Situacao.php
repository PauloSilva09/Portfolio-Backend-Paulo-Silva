<?php
class Situacao{
    public $Codigo;
    public $Nome;

    public function __construct($codigo =  null,$nome= null) {
        $this->Codigo = $codigo;
        $this->Nome = $nome;
    }

    public function Listar(){
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando= "Select cd_situacao, nm_situacao from situacao";
            $cSql = $conexao->prepare($comando);
            $cSql->execute();
            $dados = $cSql->fetchAll(PDO::FETCH_ASSOC);
            
            $situacoes = [];
            for ($i=0; $i < count($dados); $i++) { 
                $situacao = new Situacao($dados[$i]['cd_situacao'],$dados[$i]['nm_situacao']);
                array_push($situacoes,$situacao); 
            }
            
        } 
        catch (Exception $erro) 
        {
            throw new Exception("Falha na conexao");
        }
        finally{
            return $situacoes;
            $conexao = null;
        }

        }
}
?>