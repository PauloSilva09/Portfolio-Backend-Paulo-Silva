<?php

class Patrimonio {
    public $Codigo;
    public $Nome;
    public $NumeroSerie;
    public $Categoria;
    public $Localizacao;
    public $Responsavel;
    public $DataAquisicao;
    public $Valor;
    public $Situacao;
    public $Observacao;

    public function __construct(
        $codigo = null, 
        $nome = null, 
        $numeroSerie=null, 
        $categoria = null,
        $localizacao = null,
        $responsavel = null,
        $dataAquisicao = null, 
        $valor = null, 
        $situacao = null,
        $observacao = null)
    {
        $this->Codigo = $codigo;
        $this->Nome = $nome;
        $this->NumeroSerie = $numeroSerie;
        $this->Categoria = $categoria;
        $this->Localizacao = $localizacao;
        $this->Responsavel = $responsavel;
        $this->DataAquisicao = $dataAquisicao;
        $this->Valor = $valor;
        $this->Situacao = $situacao;
        $this->Observacao = $observacao;
    }

    public function Salvar($nome = null, $numeroSerie=null, $categoria = null,$localizacao = null,$responsavel = null,$dataAquisicao = null, $valor = null, $situacao = null,$observacao = null){
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio", "root", "root");
            $cSQL = $conexao->prepare('select ifnull(MAX(cd_patrimonio)+1, 1) as proximoCodigo from patrimonio');
            $cSQL->execute();
            $novo_codigo = $cSQL->fetchAll(PDO::FETCH_ASSOC);
            $cSQL = $conexao->prepare("insert into patrimonio values ({$novo_codigo[0]['proximoCodigo']}, '{$nome}', '{$numeroSerie}', {$categoria}, {$localizacao}, {$responsavel}, '{$dataAquisicao}',{$valor}, {$situacao}, '{$observacao}');");
            $cSQL->execute();
        } 
        catch (Exception $erro) {
            echo $erro->getMessage();
        }
        finally{
            $conexao = null;
        }

    }

    public function Listar($busca)
    {
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando= "select
            p.cd_patrimonio, p.nm_patrimonio, p.cd_numero_serie, c.nm_categoria, l.nm_localizacao,
            s.nm_situacao from patrimonio p join categoria c ON (p.cd_categoria = c.cd_categoria)
            JOIN localizacao l on (p.cd_localizacao = l.cd_localizacao)
            JOIN responsavel r on (p.cd_responsavel = r.cd_responsavel)
            JOIN situacao s on (p.cd_situacao = s.cd_situacao)
            WHERE p.nm_patrimonio LIKE CONCAT('%{$busca}%')
            OR p.cd_numero_serie LIKE CONCAT('%{$busca}%')
            OR c.nm_categoria LIKE CONCAT('%{$busca}%')";
            $cSql = $conexao->prepare($comando);
            $cSql->execute();
            $dados = $cSql->fetchAll(PDO::FETCH_ASSOC);
            
            $patrimonios = [];
            for ($i=0; $i < count($dados); $i++) { 
                $patrimonio = new Patrimonio($dados[$i]['cd_patrimonio'],$dados[$i]['nm_patrimonio'],$dados[$i]['cd_numero_serie'],$dados[$i]['nm_categoria'],$dados[$i]['nm_localizacao'],null,null,null,$dados[$i]['nm_situacao']);
                array_push($patrimonios,$patrimonio); 
            }
            
        } 
        catch (Exception $erro) 
        {
            echo $erro->getMessage();
        }
        finally{
            return $patrimonios;
            $conexao = null;
        }
    }

    public function Procura($codigo){
        try
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando = "select p.cd_patrimonio, p.nm_patrimonio, p.cd_numero_serie,
                        c.nm_categoria, l.nm_localizacao, r.nm_responsavel, r.nm_email,
                        r.nm_telefone, s.nm_situacao, p.dt_aquisicao, p.vl_patrimonio, p.ds_observacao
                        from patrimonio p join categoria c ON (p.cd_categoria = c.cd_categoria)
                        join localizacao l on (p.cd_localizacao = l.cd_localizacao)
                        join responsavel r on (p.cd_responsavel = r.cd_responsavel)
                        join situacao s on (p.cd_situacao = s.cd_situacao)
                        where p.cd_patrimonio = {$codigo} ";
            $cSQL = $conexao->prepare($comando);
            $cSQL->execute();
            $dados = $cSQL->fetchAll(PDO::FETCH_ASSOC);
            $patrimonios = [];
            for ($i=0; $i < count($dados); $i++) { 
                $patrimonio = new Patrimonio($dados[$i]['cd_patrimonio'],$dados[$i]['nm_patrimonio'],$dados[$i]['cd_numero_serie'],$dados[$i]['nm_categoria'],$dados[$i]['nm_localizacao'],$dados[$i]['nm_responsavel'],$dados[$i]['dt_aquisicao'],$dados[$i]['vl_patrimonio'],$dados[$i]['nm_situacao'],$dados[$i]['ds_observacao']);
                array_push($patrimonios,$patrimonio); 
            }

        }
        catch(Exception $erro){
            echo $erro->getMessage();
        }
        finally
        {
            return $patrimonios;
            $conexao = null;
        }
    }

    public function Editar($cdPatrimonio,$nmPatrimonio,$numeroSerie,$categoria,$localizacao,$reponsavel,$situacao,$dataAquisicao,$vlPatrimonio,$observacao){
        try 
        {
            $conexao = new PDO ("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando = "update patrimonio set nm_patrimonio = '{$nmPatrimonio}', cd_numero_serie =
                        '{$numeroSerie}', cd_categoria = {$categoria}, cd_localizacao = {$localizacao}, cd_responsavel = {$reponsavel}, cd_situacao = {$situacao},
                        dt_aquisicao = '{$dataAquisicao}', vl_patrimonio = {$vlPatrimonio}, ds_observacao = '{$observacao}' where cd_patrimonio = {$cdPatrimonio} ";
            $cSQL = $conexao->prepare($comando);
            $cSQL->execute();
        } 
        catch (Exception $erro) {
            echo $erro->getMessage();
        }
        finally
        {
            $conexao = null;

        }
    }
    
    public function Excluir($codigo){
        try 
        {
            $conexao = new PDO ("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando = "delete from patrimonio where cd_patrimonio = {$codigo}";
            $cSQL = $conexao->prepare($comando);
            $cSQL->execute();
        } 
        catch (Exception $erro) {
            echo $erro->getMessage();
        }
        finally
        {
            $conexao = null;
        }
    }
}

?>