<?php
class Categoria{
    public $Codigo;
    public $Nome;

    public function __construct($codigo =  null,$nome= null) {
        $this->Codigo = $codigo;
        $this->Nome = $nome;
    }

    public function Listar(){
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando= "Select cd_categoria, nm_categoria from categoria order by nm_categoria";
            $cSql = $conexao->prepare($comando);
            $cSql->execute();
            $dados = $cSql->fetchAll(PDO::FETCH_ASSOC);
            
            $categorias = [];
            for ($i=0; $i < count($dados); $i++) { 
                $categoria = new Categoria($dados[$i]['cd_categoria'],$dados[$i]['nm_categoria']);
                array_push($categorias,$categoria); 
            }
            
        } 
        catch (Exception $erro) 
        {
            echo $erro->getMessage();
        }
        finally{
            return $categorias;
            $conexao = null;
        }

        }
}
?>