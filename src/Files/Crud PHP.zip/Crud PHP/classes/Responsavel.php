<?php
class Responsavel{
    public $Codigo;
    public $Nome;
    public $Email;
    public $Telefone;

    public function __construct($codigo =  null,$nome= null,$email = null,$telefone=null) {
        $this->Codigo = $codigo;
        $this->Nome = $nome;
        $this->Email = $email;
        $this->Telefone = $telefone;
    }


    public function Listar(){
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando= "Select cd_responsavel, nm_responsavel from responsavel order by nm_responsavel";
            $cSql = $conexao->prepare($comando);
            $cSql->execute();
            $dados = $cSql->fetchAll(PDO::FETCH_ASSOC);
            
            $responsaveis = [];
            for ($i=0; $i < count($dados); $i++) { 
                $responsavel = new Responsavel($dados[$i]['cd_responsavel'],$dados[$i]['nm_responsavel']);
                array_push($responsaveis,$responsavel); 
            }
            
        } 
        catch (Exception $erro) 
        {
            echo $erro->getMessage();
        }
        finally{
            $conexao = null;
            return $responsaveis;
        }

        }


}
?>