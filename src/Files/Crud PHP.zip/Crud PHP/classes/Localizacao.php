<?php
class Localizacao{
    public $Codigo;
    public $Nome;

    public function __construct($codigo =  null,$nome= null) {
        $this->Codigo = $codigo;
        $this->Nome = $nome;
    }

    public function Listar(){
        try 
        {
            $conexao = new PDO("mysql:host=localhost;dbname=inventario_patrimonio","root","root");
            $comando= "Select cd_localizacao, nm_localizacao from localizacao order by nm_localizacao";
            $cSql = $conexao->prepare($comando);
            $cSql->execute();
            $dados = $cSql->fetchAll(PDO::FETCH_ASSOC);
            
            $localizacoes = [];
            for ($i=0; $i < count($dados); $i++) { 
                $localizacao = new Localizacao($dados[$i]['cd_localizacao'],$dados[$i]['nm_localizacao']);
                array_push($localizacoes,$localizacao); 
            }
            
        } 
        catch (Exception $erro) 
        {
            echo $erro->getMessage();
        }
        finally{
            return $localizacoes;
            $conexao = null;
        }

        }
}
?>