<?php
require_once('config.php');

if(!isset($_GET['c']) || $_GET['c'] == '' ){
    header('location: index.php');
    return;
}
$codigo = $_GET['c'];
$patrimonio = new Patrimonio();
$listaPatrimonio = $patrimonio->Procura($codigo);

?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
    <link rel="stylesheet" href="css/estiloPatrimonio.css">
    <link rel="stylesheet" href="css/estiloExcluir.css">
</head>

<body>

    <header>
        <h1>Excluir Patrimônio</h1>
        <div class="area-links">
            <a href="index.php"><span class="material-symbols-outlined">arrow_back</span> Voltar</a>
        </div>
    </header>

    <main class="principal centralizado">
        <h1 class="atencao">Tem certeza que deseja excluir?</h1>
        <?php
        for ($i=0; $i < count($listaPatrimonio); $i++) { 
            echo"<p>
                    <strong>{$listaPatrimonio[$i]->Nome}</strong><br>
                    Nº Série: {$listaPatrimonio[$i]->NumeroSerie}<br>
                    Categoria: {$listaPatrimonio[$i]->Categoria}
                </p>";
        }
        ?>
        
        <div class="area-botoes">
            <a class="btn btn-confirmar" href='index.php' <?php  $patrimonio->Excluir($codigo);?>><span class="material-symbols-outlined">delete</span>Sim, Excluir</a>
            <a href="index.php" class="btn btn-cancelar"><span class="material-symbols-outlined">cancel</span>Cancelar</a>
        </div>
    </main>

</body>

</html>