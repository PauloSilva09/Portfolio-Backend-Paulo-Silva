<?php
require_once('config.php');
$ExisteBusca = false;
if(isset($_GET['busca']) && $_GET['busca'] != '' ){
    $buscar = $_GET['busca'];
    $patrimonio = new Patrimonio();
    $listaPatrimonios = $patrimonio->Listar($buscar);
    $ExisteBusca = true;
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventário de Patrimônio</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="stylesheet" href="css/estiloGeral.css">
</head>

<body>

    <header>
        <h1>Inventário de Patrimônio</h1>
        <div class="area-links">
            <a href="novo.php"><span class="material-symbols-outlined">add_box</span> Novo Patrimônio</a>
        </div>
    </header>

    <main>
        <form method="GET" action="" class="area-barra">
            <input type="text" name="busca" placeholder="Pesquisar por nome, número de série ou categoria...">
            <button type="submit" class="btn"><span class="material-symbols-outlined">search</span>Buscar</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Nº Série</th>
                    <th>Categoria</th>
                    <th>Localização</th>
                    <th>Status</th>
                    <th class="colAcoes">Ações</th>
                </tr>
            </thead>
            <tbody>

                <?php
                if($ExisteBusca == true && $listaPatrimonios>0){

                    for ($i=0; $i < count($listaPatrimonios); $i++) { 
                        $codigoItem= $listaPatrimonios[$i]->Codigo;
                        echo"
                        <tr>
                        <td>{$codigoItem}</td>
                        <td>{$listaPatrimonios[$i]->Nome}</td>
                            <td>{$listaPatrimonios[$i]->NumeroSerie}</td>
                            <td>{$listaPatrimonios[$i]->Categoria}</td>
                            <td>{$listaPatrimonios[$i]->Localizacao}</td>
                            <td>{$listaPatrimonios[$i]->Situacao}</td>
                            <td class='acoes'>
                            <a href='ver.php?c={$codigoItem}' class='btn btn-ver'><span class='material-symbols-outlined'>folder_open</span></a>
                            <a href='editar.php?c={$codigoItem}' class='btn btn-editar'><span class='material-symbols-outlined'>edit</span></a>
                            <a href='excluir.php?c={$codigoItem}' class='btn btn-excluir'><span class='material-symbols-outlined'>delete</span></a>
                            </td>
                            </tr>";
                        }
                }
                else{
                    echo"<tr><td colspan='7'>Nenhum resultado encontrado.</td></tr>";
                }
                ?>            
            </tbody>
        </table>
    </main>

</body>

<html>