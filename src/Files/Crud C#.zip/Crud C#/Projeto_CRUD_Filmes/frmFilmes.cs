﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data;

namespace Projeto_CRUD_Filmes
{
    public partial class frmFilmes : Form
    {
        int streamingAdiciona = 0;
        int situacaoAdiciona = 0;
        int indiceFilme = 0;
        List<int> codigosStreaming = new List<int>();
        List<int> codigosSituacao = new List<int>();

        public frmFilmes()
        {
            InitializeComponent();
        }

        private void frmFilmes_Load(object sender, EventArgs e)
        {
            pnlFormulario.Location = new Point(12, 12);
            CarregarFilmes();
            Adicionalistas();
        }

        private void btnNovoFilme_Click(object sender, EventArgs e)
        {
            lblTitulo.Text = "Novo Filme";
            Limpar();
            pnlFormulario.Visible = true;
            pnlLista.Visible = false;
        }

        void CarregarFilmes()
        {
            tblFilmes.Rows.Clear();
            Filme filme = new Filme();
            List<Filme> lista = filme.Listar();
            for (int i = 0; i < lista.Count; i++)
            {
                tblFilmes.Rows.Add(lista[i].Nome, lista[i].NomeStreaming, lista[i].NomeSituacao, lista[i].Codigo);
            }
        }

        void Adicionalistas()
        {
            cmbStreaming.Items.Clear();
            Streaming streaming = new Streaming();
            List<Streaming> listaStreaming = streaming.Listar();
            for (int i = 0; i < listaStreaming.Count; i++)
            {
                codigosStreaming.Add(listaStreaming[i].Codigo);
                cmbStreaming.Items.Add(listaStreaming[i].Nome);
            }

            cmbSituacao.Items.Clear();
            Situacao situacao = new Situacao();
            List<Situacao> listaSituacao = situacao.Listar();
            for (int i = 0; i < listaSituacao.Count; i++)
            {
                codigosSituacao.Add(listaSituacao[i].Codigo);
                cmbSituacao.Items.Add(listaSituacao[i].Nome);
            }
        }

        void Limpar()
        {
            txtNome.Clear();
            cmbStreaming.SelectedIndex = -1;
            cmbSituacao.SelectedIndex = -1;
            txtNome.ReadOnly = false;
            cmbStreaming.Enabled = true;
            cmbSituacao.Enabled=true;
            btnSalvar.Text = "Salvar";
            btnCancelar.Text = "Cancelar";
            lblAtencaoExclusao.Visible = false;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpar();
            pnlFormulario.Visible = false;
            pnlLista.Visible = true;
            Filme filme = new Filme();
            List<Filme> lista = filme.Listar();
            for (int i = 0; i < lista.Count; i++)
            {
                tblFilmes.Rows.Add(lista[i].Nome, lista[i].NomeStreaming, lista[i].NomeSituacao, lista[i].Codigo);
            }
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {

            if (String.IsNullOrEmpty(txtNome.Text))
            {
                MessageBox.Show("Nome é obrigatório", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtNome.Focus();
                return;
            }
            if (String.IsNullOrEmpty(cmbStreaming.Text))
            {
                MessageBox.Show("Nome do Streaming é obrigatório", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbStreaming.Focus();
                return;
            }
            if (String.IsNullOrEmpty(cmbSituacao.Text))
            {
                MessageBox.Show("Situação é obrigatória", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbSituacao.Focus();
                return;
            }

            if (lblTitulo.Text == "Novo Filme")
            {
                //Adicionar
                Filme filme = new Filme();
                filme.Adicionar(txtNome.Text,streamingAdiciona,situacaoAdiciona);

            }
            else
            {
                if (lblTitulo.Text == "Editar Filme")
                {
                    //Editar
                    Filme filme = new Filme();
                    filme.Editar(txtNome.Text, streamingAdiciona, situacaoAdiciona,indiceFilme);
                }
                else
                {
                    //Excluir
                    Filme filme = new Filme();
                    filme.Excluir(indiceFilme);

                }
            }
            

            MessageBox.Show("Salvo com Sucesso", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Limpar();
            CarregarFilmes();
            pnlFormulario.Visible = false;
            pnlLista.Visible = true;
        }

        private void editarFilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indiceFilme = int.Parse(tblFilmes.Rows[tblFilmes.CurrentRow.Index].Cells[3].Value.ToString());

            Filme filme = new Filme();
            List<Filme> lista = filme.Procura(indiceFilme);
            for (int i = 0; i < lista.Count; i++)
            {
                txtNome.Text = lista[i].Nome;
                for ( int j = 0; j < cmbSituacao.Items.Count; j++)
                {
                    if (lista[i].CodigoSituacao == codigosSituacao[j])
                    {
                        cmbSituacao.SelectedIndex = j;
                    }
                }
                for (int h = 0; h < cmbStreaming.Items.Count; h++)
                {
                    if (lista[i].NomeStreaming == cmbStreaming.Items[h].ToString())
                    {
                        cmbStreaming.SelectedIndex = h;
                    }
                }
            }

            
            lblTitulo.Text = "Editar Filme";
            pnlLista.Visible = false;
            pnlFormulario.Visible = true;
        }

        private void excluirFilmeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indiceFilme = int.Parse( tblFilmes.Rows[tblFilmes.CurrentRow.Index].Cells[3].Value.ToString());

            Filme filme = new Filme();
            List<Filme> lista = filme.Procura(indiceFilme);
            for (int i = 0; i < lista.Count; i++)
            {
                txtNome.Text = lista[i].Nome;

                for (int j = 0; j < cmbSituacao.Items.Count; j++)
                {
                    if (lista[i].CodigoSituacao == codigosSituacao[j])
                    {
                        cmbSituacao.SelectedIndex = j;
                    }


                }
                for (int h = 0; h < cmbStreaming.Items.Count; h++)
                {
                    if (lista[i].NomeStreaming == cmbStreaming.Items[h].ToString())
                    {
                        cmbStreaming.SelectedIndex = h;
                    }
                }
            }

            txtNome.ReadOnly = true;
            cmbStreaming.Enabled = false;
            cmbSituacao.Enabled = false;

            lblTitulo.Text = "Excluir Filme";
            lblAtencaoExclusao.Visible = true;
            btnSalvar.Text = "Sim";
            btnCancelar.Text = "Não";

            pnlLista.Visible = false;
            pnlFormulario.Visible = true;
        }

        private void cmbStreaming_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indice = cmbStreaming.SelectedIndex;
            if(indice > -1)
            {
                streamingAdiciona = codigosStreaming[indice];
            }
             
        }

        private void cmbSituacao_SelectedIndexChanged(object sender, EventArgs e)
        {
            int indice = cmbSituacao.SelectedIndex;
            if(indice > -1)
            {
                situacaoAdiciona = codigosSituacao[indice];
            }

        }
    }
}
