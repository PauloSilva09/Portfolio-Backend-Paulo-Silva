﻿namespace Projeto_CRUD_Filmes
{
    partial class frmFilmes
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlLista = new System.Windows.Forms.Panel();
            this.btnNovoFilme = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tblFilmes = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Codigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editarFilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirFilmeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlFormulario = new System.Windows.Forms.Panel();
            this.cmbStreaming = new System.Windows.Forms.ComboBox();
            this.lblAtencaoExclusao = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnSalvar = new System.Windows.Forms.Button();
            this.cmbSituacao = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnlLista.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblFilmes)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.pnlFormulario.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlLista
            // 
            this.pnlLista.Controls.Add(this.btnNovoFilme);
            this.pnlLista.Controls.Add(this.label1);
            this.pnlLista.Controls.Add(this.tblFilmes);
            this.pnlLista.Location = new System.Drawing.Point(12, 12);
            this.pnlLista.Name = "pnlLista";
            this.pnlLista.Size = new System.Drawing.Size(629, 316);
            this.pnlLista.TabIndex = 0;
            // 
            // btnNovoFilme
            // 
            this.btnNovoFilme.Location = new System.Drawing.Point(487, 13);
            this.btnNovoFilme.Name = "btnNovoFilme";
            this.btnNovoFilme.Size = new System.Drawing.Size(122, 38);
            this.btnNovoFilme.TabIndex = 2;
            this.btnNovoFilme.Text = "Novo Filme";
            this.btnNovoFilme.UseVisualStyleBackColor = true;
            this.btnNovoFilme.Click += new System.EventHandler(this.btnNovoFilme_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "Filmes:";
            // 
            // tblFilmes
            // 
            this.tblFilmes.AllowUserToAddRows = false;
            this.tblFilmes.AllowUserToDeleteRows = false;
            this.tblFilmes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tblFilmes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Codigo});
            this.tblFilmes.ContextMenuStrip = this.contextMenuStrip1;
            this.tblFilmes.Location = new System.Drawing.Point(17, 86);
            this.tblFilmes.Name = "tblFilmes";
            this.tblFilmes.ReadOnly = true;
            this.tblFilmes.RowHeadersVisible = false;
            this.tblFilmes.RowHeadersWidth = 51;
            this.tblFilmes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tblFilmes.Size = new System.Drawing.Size(592, 214);
            this.tblFilmes.TabIndex = 0;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "Nome";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column2.HeaderText = "Streaming";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 113;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column3.HeaderText = "Situação";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Codigo
            // 
            this.Codigo.HeaderText = "Codigo";
            this.Codigo.MinimumWidth = 6;
            this.Codigo.Name = "Codigo";
            this.Codigo.ReadOnly = true;
            this.Codigo.Visible = false;
            this.Codigo.Width = 125;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarFilmeToolStripMenuItem,
            this.excluirFilmeToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(142, 48);
            // 
            // editarFilmeToolStripMenuItem
            // 
            this.editarFilmeToolStripMenuItem.Name = "editarFilmeToolStripMenuItem";
            this.editarFilmeToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.editarFilmeToolStripMenuItem.Text = "Editar Filme";
            this.editarFilmeToolStripMenuItem.Click += new System.EventHandler(this.editarFilmeToolStripMenuItem_Click);
            // 
            // excluirFilmeToolStripMenuItem
            // 
            this.excluirFilmeToolStripMenuItem.Name = "excluirFilmeToolStripMenuItem";
            this.excluirFilmeToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.excluirFilmeToolStripMenuItem.Text = "Excluir Filme";
            this.excluirFilmeToolStripMenuItem.Click += new System.EventHandler(this.excluirFilmeToolStripMenuItem_Click);
            // 
            // pnlFormulario
            // 
            this.pnlFormulario.Controls.Add(this.cmbStreaming);
            this.pnlFormulario.Controls.Add(this.lblAtencaoExclusao);
            this.pnlFormulario.Controls.Add(this.lblTitulo);
            this.pnlFormulario.Controls.Add(this.btnCancelar);
            this.pnlFormulario.Controls.Add(this.btnSalvar);
            this.pnlFormulario.Controls.Add(this.cmbSituacao);
            this.pnlFormulario.Controls.Add(this.label4);
            this.pnlFormulario.Controls.Add(this.label3);
            this.pnlFormulario.Controls.Add(this.txtNome);
            this.pnlFormulario.Controls.Add(this.label2);
            this.pnlFormulario.Location = new System.Drawing.Point(647, 12);
            this.pnlFormulario.Name = "pnlFormulario";
            this.pnlFormulario.Size = new System.Drawing.Size(629, 316);
            this.pnlFormulario.TabIndex = 1;
            this.pnlFormulario.Visible = false;
            // 
            // cmbStreaming
            // 
            this.cmbStreaming.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStreaming.FormattingEnabled = true;
            this.cmbStreaming.Location = new System.Drawing.Point(21, 165);
            this.cmbStreaming.Name = "cmbStreaming";
            this.cmbStreaming.Size = new System.Drawing.Size(279, 31);
            this.cmbStreaming.TabIndex = 10;
            this.cmbStreaming.SelectedIndexChanged += new System.EventHandler(this.cmbStreaming_SelectedIndexChanged);
            // 
            // lblAtencaoExclusao
            // 
            this.lblAtencaoExclusao.Location = new System.Drawing.Point(23, 211);
            this.lblAtencaoExclusao.Name = "lblAtencaoExclusao";
            this.lblAtencaoExclusao.Size = new System.Drawing.Size(585, 23);
            this.lblAtencaoExclusao.TabIndex = 9;
            this.lblAtencaoExclusao.Text = "Tem certeza que deseja excluir este filme?";
            this.lblAtencaoExclusao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAtencaoExclusao.Visible = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(18, 22);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(126, 29);
            this.lblTitulo.TabIndex = 8;
            this.lblTitulo.Text = "Novo Filme";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(486, 247);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(122, 38);
            this.btnCancelar.TabIndex = 7;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnSalvar
            // 
            this.btnSalvar.Location = new System.Drawing.Point(358, 247);
            this.btnSalvar.Name = "btnSalvar";
            this.btnSalvar.Size = new System.Drawing.Size(122, 38);
            this.btnSalvar.TabIndex = 6;
            this.btnSalvar.Text = "Salvar";
            this.btnSalvar.UseVisualStyleBackColor = true;
            this.btnSalvar.Click += new System.EventHandler(this.btnSalvar_Click);
            // 
            // cmbSituacao
            // 
            this.cmbSituacao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSituacao.FormattingEnabled = true;
            this.cmbSituacao.Location = new System.Drawing.Point(319, 165);
            this.cmbSituacao.Name = "cmbSituacao";
            this.cmbSituacao.Size = new System.Drawing.Size(289, 31);
            this.cmbSituacao.TabIndex = 5;
            this.cmbSituacao.SelectedIndexChanged += new System.EventHandler(this.cmbSituacao_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(315, 138);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 23);
            this.label4.TabIndex = 4;
            this.label4.Text = "Situação:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Streaming:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(21, 98);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(587, 31);
            this.txtNome.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nome:";
            // 
            // frmFilmes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 338);
            this.Controls.Add(this.pnlFormulario);
            this.Controls.Add(this.pnlLista);
            this.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.MaximizeBox = false;
            this.Name = "frmFilmes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gerenciamento de Filmes";
            this.Load += new System.EventHandler(this.frmFilmes_Load);
            this.pnlLista.ResumeLayout(false);
            this.pnlLista.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblFilmes)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.pnlFormulario.ResumeLayout(false);
            this.pnlFormulario.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLista;
        private System.Windows.Forms.Button btnNovoFilme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView tblFilmes;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Panel pnlFormulario;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnSalvar;
        private System.Windows.Forms.ComboBox cmbSituacao;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label lblAtencaoExclusao;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editarFilmeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirFilmeToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmbStreaming;
        private System.Windows.Forms.DataGridViewTextBoxColumn Codigo;
    }
}

