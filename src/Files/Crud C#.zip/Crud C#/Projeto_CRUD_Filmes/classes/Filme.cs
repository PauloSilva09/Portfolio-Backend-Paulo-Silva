﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;
public class Filme
{
    public int Codigo { get; set; }
    public string Nome { get; set; }
    public int CodigoStreaming { get; set; }

    public int CodigoSituacao { get; set; }

    public string NomeStreaming { get; set; }

    public string NomeSituacao { get; set; }

    public Filme()
    {

    }

    public Filme(int codigo, string nome, int codigoStreaming, int codigoSituacao)
    {
        this.Codigo = codigo;
        this.Nome = nome;
        this.CodigoStreaming = codigoStreaming;
        this.CodigoSituacao = codigoSituacao;
    }

    public Filme(int codigo, string nome, int codigoStreaming,string nomeStreaming, int codigoSituacao , string nomeSituacao)
    {
        this.Codigo = codigo;
        this.Nome = nome;
        this.CodigoStreaming = codigoStreaming ;
        this.NomeStreaming = nomeStreaming;
        this.CodigoSituacao = codigoSituacao ;
        this.NomeSituacao = nomeSituacao;
    }

    public Filme(int codigo, string nome, int codigoStreaming, int codigoSituacao, string nomeStreaming)
    {
        this.Codigo = codigo;
        this.Nome = nome;
        this.CodigoStreaming = codigoStreaming;
        this.NomeStreaming = nomeStreaming;
        this.CodigoSituacao = codigoSituacao;
    }


    public List<Filme> Listar()
    {

        List<Filme> lista = new List<Filme>();

        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("Select f.cd_filme, f.nm_filme, f.cd_streaming, s.nm_streaming, f.cd_situacao, st.nm_situacao from filme f join streaming s on (f.cd_streaming = s.cd_streaming) join situacao st on (f.cd_situacao = st.cd_situacao) order by f.cd_filme ", conexao);
            MySqlDataReader dados = cSQL.ExecuteReader();
            while (dados.Read())
            {
                Filme filme = new Filme(dados.GetInt32(0), dados.GetString(1), dados.GetInt32(2), dados.GetString(3), dados.GetInt32(4), dados.GetString(5));
                lista.Add(filme);
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }
        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível listar os Filmes");
        }
        finally
        {
            if(conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
        return lista;
    }

    public void Adicionar(string nomeFilme, int cd_streaming, int cd_situacao)
    {
        int ultimoFilme = 0;
        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);

        //Pega o numero do ultimo numero e adiciona outro filme
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("SELECT IFNULL(MAX(cd_filme)+1, 1) as proximoCodigo FROM filme", conexao);
            MySqlDataReader dados = cSQL.ExecuteReader();
            while (dados.Read())
            {
                ultimoFilme = (dados.GetInt32(0));
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }
            cSQL = new MySqlCommand("INSERT INTO filme VALUES (" + ultimoFilme + ", '" + nomeFilme + "', " + cd_streaming + ", " + cd_situacao + ");", conexao);
            cSQL.ExecuteNonQuery();

        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível adicionar o Filme");
        }
        finally
        {
            if (conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }

     
    }

    public void Editar(string nm_filme, int cd_streaming, int cd_situacao, int cd_filme)
    {
        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);

        //Pega o numero do ultimo numero e adiciona outro filme
        try
        {
            conexao.Open();                                            
            MySqlCommand cSQL = new MySqlCommand("Update filme set nm_filme = '" + nm_filme + "', cd_streaming = " + cd_streaming + ", cd_situacao = " + cd_situacao + " where cd_filme = " + cd_filme + ";", conexao);
            cSQL.ExecuteNonQuery();
            

        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível editar o Filme ");
        }
        finally
        {
            if (conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
    }

    public void Excluir(int cd_filme)
    {
        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);

        //Pega o numero do ultimo numero e adiciona outro filme
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("Delete from filme where cd_filme = "+ cd_filme +" ", conexao);
            cSQL.ExecuteNonQuery();


        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível listar os streaming");
        }
        finally
        {
            if (conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
    }

    public List<Filme> Procura(int Codigo)
    {
        List<Filme> lista = new List<Filme>();

        string linhaConexao = "SERVER=localhost;UID=root;PASSWORD=root;DATABASE=projeto_filmes";
        MySqlConnection conexao = new MySqlConnection(linhaConexao);
        try
        {
            conexao.Open();
            MySqlCommand cSQL = new MySqlCommand("Select f.cd_filme, f.nm_filme, f.cd_streaming, f.cd_situacao, s.cd_streaming,s.nm_streaming, f.cd_situacao from filme f join streaming s on (f.cd_streaming =s.cd_streaming) where f.cd_filme =" +Codigo+ "", conexao);
            MySqlDataReader dados = cSQL.ExecuteReader();
            while (dados.Read())
            {
                Filme filme = new Filme(dados.GetInt32(0), dados.GetString(1), dados.GetInt32(2), dados.GetInt32(3), dados.GetString(5));
                lista.Add(filme);
            }
            if (!dados.IsClosed)
            {
                dados.Close();
            }
        }
        catch (System.Exception)
        {
            throw new Exception("Não foi possível achar o Filme");
        }

        finally
        {
            if (conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }
        return lista;
    }

}
